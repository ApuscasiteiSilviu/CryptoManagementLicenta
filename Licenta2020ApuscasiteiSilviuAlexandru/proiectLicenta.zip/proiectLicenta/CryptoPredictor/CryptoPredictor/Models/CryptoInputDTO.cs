﻿namespace CryptoPredictor.Models
{
    public class CryptoInputDTO
    {
        public string CoinName { get; set; }
    }
}
