package thirdParty;

import java.util.List;

public class DataModel {
    public List<CoinExchange> Data;

}
