package thirdParty;

public class CryptoCompare {

    public DataModel Data;
}
