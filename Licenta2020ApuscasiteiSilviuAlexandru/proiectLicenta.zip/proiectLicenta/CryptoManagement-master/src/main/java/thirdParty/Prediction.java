package thirdParty;

public class Prediction {

    private Float coinPrice;
    private String date;
    private String currency;

    public Float getCoinPrice() {
        return coinPrice;
    }

    public void setCoinPrice(Float coinPrice) {
        this.coinPrice = coinPrice;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }
}
