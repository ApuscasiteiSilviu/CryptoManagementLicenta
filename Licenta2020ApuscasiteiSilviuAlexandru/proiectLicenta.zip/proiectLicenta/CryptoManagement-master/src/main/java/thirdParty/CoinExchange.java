package thirdParty;

public class CoinExchange {
    public Double high;
}
