package util;

public class CryptoCoinMapping {

    public static String getAppValue(String cryptoCoin){
        return cryptoCoin + "USD";
    }
}
