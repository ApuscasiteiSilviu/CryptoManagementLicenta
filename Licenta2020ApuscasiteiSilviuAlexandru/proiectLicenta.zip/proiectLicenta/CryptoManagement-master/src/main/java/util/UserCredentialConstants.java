package util;

public interface UserCredentialConstants {
    String CRYPTO_COIN = "cryptoCoin";
    String GMAIL_ACCOUNT = "gmailAccount";

}
